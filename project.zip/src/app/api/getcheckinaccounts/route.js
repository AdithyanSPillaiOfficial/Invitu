import { NextResponse } from "next/server";
import { getDB, getUserWithSession } from "../db";
import { ObjectId } from "mongodb";

export async function POST(request) {
    const req = await request.json();
    try {
        if (!req.sessionid || !req.eventid) {
            return NextResponse.json({
                success: false,
                rescode: 0,
                error: "Invalid Request"
            })
        }

        const user = await getUserWithSession(req.sessionid);

        if (!user) {
            return NextResponse.json({
                success: false,
                rescode: 301,
                error: "Invalid Session"
            })
        }

        const db = await getDB();
        const event = await db.collection("events").aggregate([
            {
                $match: {
                    _id: new ObjectId(req.eventid)
                }
            },
            {
                $lookup: {
                    from: "users",
                    localField: "checkinaccounts",
                    foreignField: "_id",
                    as: "checkinaccounts"
                }
            }
        ]).toArray();
        console.log(event);
        if(event.length > 0) {
            const checkinaccounts = event[0].checkinaccounts.map(({_id, name, username, email}) => ({_id, name, username, email}));
            return NextResponse.json({
                success: true,
                checkinaccounts: checkinaccounts
            });
        }
        else {
            return NextResponse.json({
                success: false,
                rescode: 305,
                error: "Invalid Event or Your Account is not associated with the event"
            })
        }
    } catch (error) {
        return NextResponse.json({
            success: false,
            rescode: 202,
            error: "Something went wrong"
        })
    }
}