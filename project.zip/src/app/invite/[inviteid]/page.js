"use client";
import BirthdayInvite from '@/components/invites/BirthdayInvite';
import HousewarmingInvite from '@/components/invites/HouseWarming';
import NamingCeremonyInvite from '@/components/invites/NamingCeremonyInvite';
import OthersEventInvites from '@/components/invites/OthersEventInvites';
import WeddingInvite from '@/components/invites/WeddingInvite';
import React, { use, useEffect, useState } from 'react';
import { toast } from 'react-toastify';

function Page({ params }) {
  params = use(params);
  const [invite, setInvite] = useState({});

  async function fetchInvite() {
    const result = await fetch("/api/getinvitedetails", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ inviteid: params.inviteid })
    });

    if (result.ok) {
      const res = await result.json();
      if (res.success) {
        setInvite(res.invite);
      } else {
        toast.error(res.error);
      }
    }
  }

  useEffect(() => {
    fetchInvite();
  }, []); 

  return (
    <div>
      {(invite?.event?.type === "wedding" || invite?.event?.type === "engagement") && (<WeddingInvite invite={invite} />)}
      {invite?.event?.type === "housewarming" && <HousewarmingInvite invite={invite} />}
      {invite?.event?.type === "birthday" && <BirthdayInvite invite={invite} />}
      {invite?.event?.type === "naming" && <NamingCeremonyInvite invite={invite} />}
      {invite?.event?.type === "others" && <OthersEventInvites invite={invite} />}
    </div>
  );
}

export default Page;
