"use client";
import KnowYourInvitesForm from '@/components/KnowYourInvitesForm'
import { useLoading } from '@/contexts/LoadingContext';
import Loading from '@/widgets/Loading';
import React, { Suspense } from 'react'
import { toast } from 'react-toastify';

function page() {
    async function handleSubmit(e, searchText) {
        e.preventDefault();
        const {setLoading} = useLoading();

        setLoading(true);

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneRegex = /^\+?[0-9\s()-]{7,20}$/;

        if (emailRegex.test(searchText)) {
            toast.success(`Processing search for Email address ${searchText}`)
        }
        else if (phoneRegex.test(searchText)) {
            toast.success(`You Searched Phone number ${searchText}`);
        }
        else {
            toast.error("You entered an Invalid value")
        }

        if (emailRegex.test(searchText) || phoneRegex.test(searchText)) {

        }
    }
    return (
        <div>
            <Suspense fallback={<Loading />}>
                <KnowYourInvitesForm handleSubmit={handleSubmit} />
            </Suspense>
        </div>
    )
}

export default page